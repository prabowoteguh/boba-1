function penjumlahan1(a, b) {
    let total;
    total = a + b

    return total
}

const penjumlahan2 = function (a, b) {
    let total;
    total = a + b

    return total
}

const penjumlahan3 = (a, b) => {
    let total;
    total = a + b

    return total
}

//CARA PANGGIL FUNCTION
console.log( penjumlahan3(1, 2) )